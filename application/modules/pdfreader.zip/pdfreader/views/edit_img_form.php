 <div class="col-md-12 col-xs-12 center " id="edit_image_wrap" style="display:none;margin: 40px 0px 0px;  padding: 0 0 15px;">
 <div  id="btn_close_edit_image_wrap" class="btn btn-box-tool pull-right" onclick="hide_this('edit_image_wrap')">
<i class="fa fa-times">
              </i>
</div>
<form id="form_edit_image" name="form_edit_image" style="margin: 0px;" enctype="multipart/form-data" method="post" class="form-bordered">
<div class="col-md-12 col-xs-12" >
<div id="edit_small_image_div" ></div>


<div style="margin-top:20px">
<div class="col-md-4 col-xs-4">
<input class="" name="edit_image" id="edit_image" size="20" type="file">
</div>
<div class="col-md-4 col-xs-4">
<input class="btn btn-success " value="upload" type="submit">
</div>
</div>
<input name="edit_img_id" id="edit_img_id"  type="hidden">
<input name="edit_image_hidden" id="edit_image_hidden"  type="hidden">
</div>

</form>
                </div> 
                <div class="clearfix">&nbsp;</div>